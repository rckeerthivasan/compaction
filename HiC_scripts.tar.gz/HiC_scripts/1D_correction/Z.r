
	ra = igraph::running.mean
	sraY = function (v, bin)
	{
		mean = c()
		for (n in (bin+1):(length(v)-bin+1))
		{
			pos = mean(v[(n-bin):(n+bin-1)])
			mean = c(mean, pos)
		}
		return (mean)
	}

	sraX = function (v, bin)
	{
		mean = c()
		for (n in (bin+1):(length(v)-bin+1))
		{
			pos = v[n]
			mean = c(mean, pos)
		}
		return (mean)
	}

	args <- commandArgs(TRUE)
	c = args[1]
	n = as.integer(args[2])
	a = read.table (c, sep="\t")

	c2 = sraX (a[,2], 10)
	c3 = sraY (a[,n], 10)
	c1 = 1:length (c2)

	b = data.frame (a[c1,1], c2, c2+10000, ((c3-median(c3))/(sd(c3))))
	write.table (b, "out/out.0.txt", row.names=F, col.names=F, sep="\t", quote=F)
	

