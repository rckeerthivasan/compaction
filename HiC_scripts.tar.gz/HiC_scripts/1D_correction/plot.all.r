
	lads = function (chr2, ylim)
	{
		l = read.table (paste("../data/lads2/chrwise/chr",chr2,".txt",sep=""))
		for (i in 1:length(l[,1]))
		{
			segments (l[i,2], ylim, l[i,3], ylim, lwd=3)
		}
	}
	
	for (chr in 1:19)
	{
		png (paste("figures/chr",chr,".2.png",sep=""), width=1200, height=800, units="px", pointsize=12)
		par (mfrow=c(3,1), mar=c(2,2,2,2), cex.axis=1.5, lwd=2)

		for (out in 9:11)
		{
			a = read.table (paste("out/out.4.chr",chr,".",out,".txt",sep=""))

			d = c()
			for (i in 3:(length(a[,1])-2))
			{
				l2=i-2; l1=i-1; r1=i; r2=i+1;
				if (a[l2,7]=="yes" && a[l1,7]=="yes" && a[r1,7]=="yes" && a[r2,7]=="yes")
				{
					if ( (a[l1,5] == a[l2,5]) && (a[r1,5] == a[r2,5]) && (a[l1,5] != a[r1,5]) )
					{
						d = c(d, a[r1,2])
					}
				}		
			}

			plot (a[,2], a[,4], type="l", ylim=c(-3,3), lwd=2, col="grey")
			for (i in 2:length(d))
			{
				left  = d[i-1]
				right = d[i]
				c = a[,5][a[,2]>=left & a[,2]<=right]
				if (mean(c)>0.7 && (left-right)!=10000)
				{
					segments (left, 0, right, 0, col="red", lwd=2)
					chr3 = paste ("chr",chr,sep="")
					write (paste (chr3, left, right, "red", sep="\t"), paste("out.2/out.5.chr",chr,".",out,".txt",sep=""), append=T)
				}
			}

			ad = a[,5]/-1
			for (i in 2:length(d))
			{
				left  = d[i-1]
				right = d[i]
				c = ad[a[,2]>=left & a[,2]<=right]
				if (mean(c)>0.7 && (left-right)!=10000)
				{
					segments (left, 0, right, 0, col="blue", lwd=2)
					chr3 = paste ("chr",chr,sep="")
					write (paste (chr3, left, right, "blue", sep="\t"), paste("out.2/out.5.chr",chr,".",out,".txt",sep=""), append=T)
				}
			}
			lads (chr, -3)
		}
		dev.off ()
	}

