
	a = read.table ("all.data.txt")
	deg=1; sp=0.55; fam="gaussian";

	png ("correction.loess.png", width=900, height=300, units="px", pointsize=12)
	par (mfrow=c(1,3))
	for (n in 6:8)
	{
		print (n) 

		g = a[,4]
		r = a[,5]
		y = a[,n]/sum(as.numeric(a[,n]))

		lt = loess (y ~ r, span=sp, degree=deg, family=fam)
		c = lt$residuals

		lt2 = loess (c ~ g, span=sp, degree=deg, family=fam)
		d = lt2$residuals

		plot (y, d)
		a = data.frame (a, d)
	}

	write.table (data.frame (a), "all.data.corrected.txt", row.names=F, col.names=F, quote=F, sep="\t")

