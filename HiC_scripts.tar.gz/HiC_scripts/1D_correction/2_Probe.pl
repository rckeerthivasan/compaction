
	use strict;
	use warnings;

	my @c0 = my @c1 = my @c2 = my @c3 = my @c4 = (); 
	open (F, $ARGV[0]) or die;
	while (<F>)
	{
		chomp ($_);
		my @C = split (/\t/, $_);
		push(@c0,$C[0]);
		push(@c1,$C[1]);
		push(@c2,$C[2]);
		push(@c3,$C[3]);
		push(@c4,$C[4]);
	}
	my $nc1=@c1;
	
	for(my $i=20; $i<$nc1-20; $i++)
	{
		my $sum1 = my $sum2=0;
		for(my $j=$i-20; $j<$i; $j++)
		{
			$sum1=$sum1+$c4[$j];
		}
		for(my $j=$i+1; $j<$i+21; $j++)
		{
			$sum2=$sum2+$c4[$j];
		}
		my $diff = abs ($sum1-$sum2);
		
		print "$c0[$i]\t$c1[$i]\t$c2[$i]\t$c3[$i]\t$c4[$i]\t$diff\n";
	}

