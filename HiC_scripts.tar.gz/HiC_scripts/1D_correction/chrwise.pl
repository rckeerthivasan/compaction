
	use warnings;
	use strict;

	foreach my $chr (1..19)
	{
		`awk '(\$1=="chr$chr")'{print} all.data.corrected.txt > chrwise/chr$chr.txt`;
	}
