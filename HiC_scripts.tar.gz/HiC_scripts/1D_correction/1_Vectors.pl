
	use strict;
	use warnings;

	open (F, $ARGV[0]) or die;
	my @a = <F>;
	close F; 
	
	for(my $i=0; $i<@a; $i++)
	{
		chomp ($a[$i]);
		my @C=split(/\t/,$a[$i]);
		print "$C[0]\t$C[1]\t$C[2]\t$C[3]\t";
	
		if ($C[3]==0)
		{
			print "-1\n"
		}		
		elsif($C[3]<0)
		{
			print "-1\n";
		}
		elsif ($C[3]>0)
		{
			print "1\n";
		}
	}

