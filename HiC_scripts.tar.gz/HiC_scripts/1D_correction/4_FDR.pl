
	use warnings;
	use strict;

	my @org = my @all = (); 
	open (F, $ARGV[0]) or die;
	while (<F>)
	{
		chomp ($_);
		my @a = split (/\t/, $_);
		push @org, $a[5];
	}

	my @count = (0) x scalar @org;
	for (my $it=1; $it<=1000; $it++)
	{
		open (G, "rand/$it.txt") or die;
		my @rand = <G>;
		for (my $i=0; $i<@org; $i++)
		{
			chomp ($org[$i]);
			chomp ($rand[$i]);
			
			$count[$i]++ if ($rand[$i]<$org[$i]);
		}
		close G;
	}

	open (F, $ARGV[0]) or die;
	@all = <F>;

	for (my $i=0; $i<@count; $i++)
	{
		chomp ($all[$i]); 
		my @a = split (/\t/, $all[$i]);
		my $sig = "no"; $sig = "yes" if ($count[$i] > 950);
		print "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$count[$i]\t$sig\n";
	}
