
	use strict;
	use warnings;
	use List::Util 'shuffle';

	my @binary;
	open (F, $ARGV[0]) or die;
	while (<F>)
	{
		chomp ($_);
		my @C = split(/\t/, $_);
		push (@binary, $C[4]);
	}
	close F;
	my $n = scalar @binary;
	
	for (my $it=1; $it<=1000; $it++)
	{	
		my @rand=shuffle(@binary);

		open (O, ">rand/$it.txt") or die;
		for(my $i=20; $i<$n-20; $i++)
		{
			my $sum1 = my $sum2 = 0;
			for(my $j=$i-20; $j<$i; $j++)
			{
				$sum1=$sum1+$rand[$j];
			}
			for(my $j=$i+1; $j<$i+21; $j++)
			{
				$sum2=$sum2+$rand[$j];
			}
			my $diff = abs ($sum1-$sum2);
			
			print O "$diff\n";
		}
		close O; 
	}


