	
	a = read.table ("../data/gc.mm10.10kb/mapped.out")	# contain GC content
	r = read.table ("../data/RE/mapped.1.out")		# contains restriction site density

	b = read.table ("../data/GSE96107.h/mapped.1.txt")	# read count of ES
	c = read.table ("../data/GSE96107.h/mapped.2.txt")	# read count of NP
	d = read.table ("../data/GSE96107.h/mapped.3.txt")	# read count of CN
	
	frame = data.frame (a, r[,4], b[,4], c[,4], d[,4])
	write.table (frame, "all.data.txt", row.names=F, col.names=F, sep="\t", quote=F)

