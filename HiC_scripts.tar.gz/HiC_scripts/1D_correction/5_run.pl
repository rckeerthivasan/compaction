
	use warnings;
	use strict;
	
	my $date = `date`; print "Started at\t$date";

	for (my $chr=1; $chr<=19; $chr++)
	{
		print "chr$chr is being done\n";
		my @files = (9..11);
		foreach my $ele (@files)
		{
			`Rscript Z.r chrwise/chr$chr.txt $ele`;
			`perl 1_Vectors.pl out/out.0.txt > out/out.1.txt`;
			`perl 2_Probe.pl   out/out.1.txt > out/out.2.txt`;
			`perl 3_Rand.pl    out/out.1.txt`;
			`perl 4_FDR.pl     out/out.2.txt > out/out.4.chr$chr.$ele.txt`;

			print "$ele is done\n"
		}
	}

	$date = `date`; print "Ended at\t$date";

