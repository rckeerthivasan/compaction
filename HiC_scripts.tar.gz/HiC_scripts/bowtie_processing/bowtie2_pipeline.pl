
	use warnings;
	use strict;
	
	`mkdir sams bams bams.sorted bams.nodup`;
	foreach my $ele (39,40)
	{
		print "$ele is processing\n"; 

		`fastq-dump -I --split-files sra/SRR15048$ele.sra`; print "fastq-dumped\n";		
		`bowtie2 -x /run/media/ken/extension/indexed/mm10/mm10 --fast -p15 -q SRR15048${ele}_1.fastq -S sams/SRR15048$ele.1.sam`; 
		`bowtie2 -x /run/media/ken/extension/indexed/mm10/mm10 --fast -p15 -q SRR15048${ele}_2.fastq -S sams/SRR15048$ele.2.sam`; 
		`rm *fastq`; print "mapping is done\n"; 

		foreach my $ele2 (1,2)
		{
			`samtools view -bS -@ 15 sams/SRR15048$ele.$ele2.sam > bams/SRR15048$ele.$ele2.bam`; 
		}
		`rm sams/*`;
	}
