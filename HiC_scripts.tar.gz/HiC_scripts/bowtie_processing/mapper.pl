
	use strict;
	use warnings;
	use POSIX;

	my %hash = ();
	open (F, "binned.mm10.10kb.txt") or die;
	while (<F>)
	{
		chomp ($_);
		my @a = split (/\t/, $_);
		my $key = "$a[0]\t$a[1]";
		$hash{$key} = 0;
	}
	close F; 

	foreach my $chr (39,40)
	{
		foreach my $pair (1,2)
		{
			print "beds/SRR15048$chr.$pair.bed is being mapped\n";
			open (G, "beds/SRR15048$chr.$pair.bed") or die;
			while (<G>)
			{
				chomp ($_);
				my @b = split (/\t/, $_);
			
				if ($b[0]=~"chr" and $b[4]>=20)
				{
					my $c = floor ($b[1] / 10000) * 10000;
					my $key = "$b[0]\t$c";
					$hash{$key} += 1;
				}
			}
			close G;
		}
	}

	open (O, ">mapped.out") or die;
	open (F, "binned.mm10.10kb.txt") or die;
	while (<F>)
	{
		chomp ($_);
		my @a = split (/\t/, $_);
		my $key = "$a[0]\t$a[1]";
		print O "$_\t$hash{$key}\n"; 
	}
	close F; close O;

