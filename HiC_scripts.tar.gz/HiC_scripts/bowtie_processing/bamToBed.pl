
	use warnings;
	use strict;
	
	foreach my $ele (39,40)
	{
		print "$ele is processing\n"; 

		foreach my $ele2 (1,2)
		{
			`bedtools bamtobed -i bams.nodup/SRR15048$ele.$ele2.bam > beds/SRR15048$ele.$ele2.bed`;
			print "$ele\t$ele2 is done\n";
		}
	}
