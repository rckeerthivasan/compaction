
	use warnings;
	use strict;
	
	foreach my $ele (39,40)
	{
		print "$ele is processing\n"; 

		foreach my $ele2 (1,2)
		{
			`samtools sort -@ 5 bams/SRR15048$ele.$ele2.bam > bams.sorted/SRR15048$ele.$ele2.bam`;
			`samtools index -@ 5 bams.sorted/SRR15048$ele.$ele2.bam`; 
			`samtools markdup -r -@ 5 bams.sorted/SRR15048$ele.$ele2.bam bams.nodup/SRR15048$ele.$ele2.bam`;
			print "$ele2 - duplicates removed\n";
		}
	}
