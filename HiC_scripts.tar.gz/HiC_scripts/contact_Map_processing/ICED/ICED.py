
from mirnylib.h5dict import h5dict
from mirnylib.numutils import *
import matplotlib.pyplot as plt 
import numpy as np 
import os


for i in range(1,20):
	j = str (i)
	inp = "".join (["chrwise.mat/es.chr",j,".txt"])
	out = "".join (["chrwise.10kb.iced.hiclib/es.chr",j,".ice.txt"])
	print (inp)
	xx=np.loadtxt(inp)
	np.savetxt(out,completeIC(xx),delimiter='\t')

for i in range(1,20):
	j = str (i)
	inp = "".join (["chrwise.mat/np.chr",j,".txt"])
	out = "".join (["chrwise.10kb.iced.hiclib/np.chr",j,".ice.txt"])
	print (inp)
	xx=np.loadtxt(inp)
	np.savetxt(out,completeIC(xx),delimiter='\t')

for i in range(1,20):
	j = str (i)
	inp = "".join (["chrwise.mat/cn.chr",j,".txt"])
	out = "".join (["chrwise.10kb.iced.hiclib/cn.chr",j,".ice.txt"])
	print (inp)
	xx=np.loadtxt(inp)
	np.savetxt(out,completeIC(xx),delimiter='\t')

