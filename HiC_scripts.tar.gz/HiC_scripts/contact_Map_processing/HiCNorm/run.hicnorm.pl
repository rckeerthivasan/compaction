	
	use warnings;
	use strict;

	foreach my $ele (1..19)
	{
		print "$ele is being done\n";

		`cut -f1,2,4,5 density/es.chr$ele.txt > density/es.chr$ele.hicnorm.txt`;
		`cut -f1,2,4,5 density/np.chr$ele.txt > density/np.chr$ele.hicnorm.txt`;
		`cut -f1,2,4,5 density/cn.chr$ele.txt > density/cn.chr$ele.hicnorm.txt`;

		`Rscript HiCNorm.R -f /run/media/kenhp/extension2/hicnorm/makeGF.mouse/gf.mm10.final.fil.10kb.txt -i density/es.chr$ele.hicnorm.txt -o chrwise.10kb.hicnorm/es.chr$ele.txt`;
		`Rscript HiCNorm.R -f /run/media/kenhp/extension2/hicnorm/makeGF.mouse/gf.mm10.final.fil.10kb.txt -i density/np.chr$ele.hicnorm.txt -o chrwise.10kb.hicnorm/np.chr$ele.txt`;
		`Rscript HiCNorm.R -f /run/media/kenhp/extension2/hicnorm/makeGF.mouse/gf.mm10.final.fil.10kb.txt -i density/cn.chr$ele.hicnorm.txt -o chrwise.10kb.hicnorm/cn.chr$ele.txt`;
	}
