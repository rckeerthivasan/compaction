
	use warnings;
	use strict;

	my %hash = (); my %count = ();
	open (F, $ARGV[2]) or die;
	while (<F>)
	{
		chomp ($_);
		my @a = split (/\t/, $_);
		
		if ($ARGV[3] eq "deco")
		{
			$hash{$a[0]} = "$a[9]\t$a[12]";
		}
		elsif ($ARGV[3] eq "cond")
		{
			$hash{$a[0]} = "$a[10]\t$a[13]";
		}
		elsif ($ARGV[3] eq "mix")
		{
			$hash{$a[0]} = "$a[11]\t$a[14]";
		}
	}
	close F;

	foreach my $chr (1..19)
	{
		open (O, ">out/$ARGV[0].es.chr$chr.$ARGV[1].txt") or die;
		open (F, "../../out.sep/$ARGV[0].es.chr$chr.$ARGV[1].txt") or die;
		while (<F>)
		{
			chomp ($_);
			my @a = split (/\t/, $_);
			my $dis = abs ($a[2] - $a[1]);

			if ($a[3]>0 and $_ !~ m/N/)
			{
				if (exists $hash{$dis})
				{
					my $val = $hash{$dis};
					my @b = split (/\t/, $val);
					$a[3] = $a[3] - ($b[0]-$b[1]); 
					print O "$a[0]\t$a[1]\t$a[2]\t$a[3]\n";
				}
			}			
		}
		close F; close O;
	}


