	
	library ("preprocessCore")

	a = read.table ("raw.txt")
	d = data.frame (a[,2]/a[,3], a[,5]/a[,6])
	q = normalize.quantiles(as.matrix(d))
	write.table (data.frame(a,q), "raw.q.txt", col.names=F, row.names=F, quote=F, sep="\t")

	a = read.table ("hcn.txt")
	d = data.frame (a[,2]/a[,3], a[,5]/a[,6])
	q = normalize.quantiles(as.matrix(d))
	write.table (data.frame(a,q), "hcn.q.txt", col.names=F, row.names=F, quote=F, sep="\t")

	a = read.table ("ice.txt")
	d = data.frame (a[,2]/a[,3], a[,5]/a[,6])
	q = normalize.quantiles(as.matrix(d))
	write.table (data.frame(a,q), "ice.q.txt", col.names=F, row.names=F, quote=F, sep="\t")


